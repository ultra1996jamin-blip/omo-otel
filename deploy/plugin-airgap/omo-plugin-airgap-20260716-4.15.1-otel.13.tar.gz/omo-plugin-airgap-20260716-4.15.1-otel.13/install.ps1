# ─────────────────────────────────────────────────────────────────────────────
# omo-plugin-install.ps1  (패키지에 install.ps1 로 포함됨)
# 폐쇄망 서버에서 실행: 플러그인 빌드 설치 → opencode 설정에 등록
#
# 이미 존재하는 opencode.json / oh-my-openagent.json 은 절대 덮어쓰지 않고
# 백업(.bak-YYYYMMDDHHmmss) 후 병합합니다.
# ─────────────────────────────────────────────────────────────────────────────
param(
  [string]$InstallPath = "C:\oh-my-openagent-plugin"
)
$ErrorActionPreference = "Stop"
function info { param($m) Write-Host "[INFO]  $m" -ForegroundColor Green }
function step { param($m) Write-Host "[STEP]  $m" -ForegroundColor Cyan }
function warn { param($m) Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function err  { param($m) Write-Host "[ERROR] $m" -ForegroundColor Red; exit 1 }

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
$CONFIG_DIR = Join-Path $env:USERPROFILE ".config\opencode"

if (-not (Get-Command opencode -ErrorAction SilentlyContinue)) {
  warn "opencode CLI가 PATH에 없습니다 — 플러그인 설치는 계속하지만, opencode 자체는 별도로 설치해야 합니다."
}

# STEP 1: 플러그인 파일 배치
step "STEP 1: 플러그인 빌드 배치 → $InstallPath"
if (Test-Path $InstallPath) {
  warn "기존 설치 발견 — dist\, packages\ 만 교체합니다 (설정은 건드리지 않음)"
  Remove-Item (Join-Path $InstallPath "dist") -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $InstallPath "packages") -Recurse -Force -ErrorAction SilentlyContinue
} else {
  New-Item -ItemType Directory -Force -Path $InstallPath | Out-Null
}
Copy-Item (Join-Path $ROOT "plugin\dist") (Join-Path $InstallPath "dist") -Recurse -Force
$distIndex = Join-Path $InstallPath "dist\index.js"
if (-not (Test-Path $distIndex)) { err "복사 실패: $distIndex 없음" }
info "  배치 완료: $distIndex"

# dist/index.js가 자기 위치 기준 상위로 packages/lsp-daemon, packages/lsp-tools-mcp 를
# 찾으므로(LSP MCP 툴), dist/의 형제 디렉터리로 그대로 복사해야 한다.
$pluginPackagesSrc = Join-Path $ROOT "plugin\packages"
if (Test-Path $pluginPackagesSrc) {
  Copy-Item $pluginPackagesSrc (Join-Path $InstallPath "packages") -Recurse -Force
  info "  배치 완료: $(Join-Path $InstallPath 'packages')  (LSP MCP 툴)"
} else {
  warn "  packages\ 없음 — LSP(정의로 이동 등) 툴은 비활성화됩니다"
}

# 경로는 file:/// URI 형식이어야 하고, 백슬래시는 슬래시로
$pluginUri = "file:///" + ($distIndex -replace '\\', '/')

# STEP 2: opencode.json 에 plugin 등록 (기존 항목 보존, 중복 방지)
step "STEP 2: opencode.json 플러그인 등록"
New-Item -ItemType Directory -Force -Path $CONFIG_DIR | Out-Null
$opencodeJsonPath = Join-Path $CONFIG_DIR "opencode.json"
$timestamp = Get-Date -Format "yyyyMMddHHmmss"

if (Test-Path $opencodeJsonPath) {
  Copy-Item $opencodeJsonPath "$opencodeJsonPath.bak-$timestamp" -Force
  info "  기존 설정 백업: $opencodeJsonPath.bak-$timestamp"
  $cfg = Get-Content $opencodeJsonPath -Raw | ConvertFrom-Json -AsHashtable
} else {
  $cfg = [ordered]@{ '$schema' = "https://opencode.ai/config.json" }
}

if (-not $cfg.ContainsKey("plugin")) { $cfg["plugin"] = @() }
$existingPlugins = @($cfg["plugin"] | Where-Object { $_ -notmatch "oh-my-openagent" -and $_ -notmatch "omo-plugin" })
$dupCount = @($cfg["plugin"]).Count - $existingPlugins.Count
if ($dupCount -gt 0) {
  warn "  기존에 등록된 oh-my-openagent 관련 plugin 항목 $dupCount 개를 교체합니다 (중복 등록은 OMO 자체 방어로 자동 비활성화됨)"
}
$cfg["plugin"] = @($existingPlugins) + @($pluginUri)
$cfg | ConvertTo-Json -Depth 20 | Set-Content $opencodeJsonPath -Encoding UTF8
info "  plugin 등록: $pluginUri"

# STEP 3: oh-my-openagent.json (otel.enabled + 모델 매핑) — 없을 때만 설치
step "STEP 3: oh-my-openagent.json 설정"
$omoJsonPath = Join-Path $CONFIG_DIR "oh-my-openagent.json"
if (Test-Path $omoJsonPath) {
  Copy-Item $omoJsonPath "$omoJsonPath.bak-$timestamp" -Force
  info "  기존 설정 백업: $omoJsonPath.bak-$timestamp"
  $omoCfg = Get-Content $omoJsonPath -Raw | ConvertFrom-Json -AsHashtable
  if (-not $omoCfg.ContainsKey("otel")) { $omoCfg["otel"] = @{} }
  $omoCfg["otel"]["enabled"] = $true
  $omoCfg | ConvertTo-Json -Depth 20 | Set-Content $omoJsonPath -Encoding UTF8
  info "  기존 설정 유지 + otel.enabled=true 만 반영 (모델 매핑 등은 그대로)"
} else {
  Copy-Item (Join-Path $ROOT "config-templates\oh-my-openagent.json") $omoJsonPath -Force
  info "  신규 설치: 검증된 free 모델 매핑 + otel.enabled=true 템플릿 적용"
}

# STEP 4: 실행 스크립트 배치
step "STEP 4: 실행 스크립트"
$startScriptDest = Join-Path $InstallPath "start-opencode.ps1"
Copy-Item (Join-Path $ROOT "config-templates\start-opencode.ps1") $startScriptDest -Force
info "  배치 완료: $startScriptDest"

# STEP 5: 완료 안내
step "STEP 5: 완료"
Write-Host ""
info "설치 위치     : $InstallPath"
info "opencode.json : $opencodeJsonPath"
info "다음 명령으로 실행 (관측 스택이 먼저 떠 있어야 함):"
Write-Host ""
Write-Host "  powershell -NoProfile -ExecutionPolicy Bypass -File `"$startScriptDest`"" -ForegroundColor White
Write-Host ""
warn "opencode를 이미 띄워 놓은 상태였다면 반드시 완전히 재시작하세요 — 플러그인은 시작 시 1회만 로드됩니다."
info "자세한 내용은 README.md 참고"
