# oh-my-openagent OTEL 계측 플러그인 — 폐쇄망 설치·사용 설명서

이 패키지는 실제로 트레이스를 만들어내는 **oh-my-openagent(OMO) 플러그인 빌드** 자체를 담습니다.
`omo-observability-airgap-YYYYMMDD.tar.gz`(관측 스택: Jaeger/OpenLIT/ClickHouse/Prometheus/Grafana)와는
**별개 패키지**이며, 모니터링이 실제로 동작하려면 **둘 다** 같은 서버(또는 최소한 같은 네트워크)에 설치해야 합니다.

```
[opencode.exe 안의 OMO 플러그인] --OTLP/HTTP JSON--> [otel-collector] --> Jaeger / ClickHouse+OpenLIT / Prometheus+Grafana
        (이 패키지가 설치하는 것)                      (omo-observability-airgap 패키지가 설치하는 것)
```

---

## 1. 사전 요구사항

- 대상 서버: **Windows 11 + Docker Desktop** (이 프로젝트를 만든 환경과 동일)
- `omo-observability-airgap-YYYYMMDD.tar.gz` 패키지가 **먼저** 설치·기동되어 있어야 함 (`AIRGAP-MONITORING-GUIDE.md` 참고)
- opencode CLI가 이미 설치되어 있고 사내 LLM API 인증이 되어 있을 것 (OMO는 이 위에 얹히는 플러그인이므로 opencode 자체 설치는 이 패키지 범위 밖)
- PowerShell 7+

---

## 2. 패키지 전송 및 검증

```powershell
$h = (Get-FileHash .\omo-plugin-airgap-YYYYMMDD.tar.gz -Algorithm SHA256).Hash.ToLower()
$h; Get-Content .\omo-plugin-airgap-YYYYMMDD.tar.gz.sha256
# 두 값이 같아야 정상
```

## 3. 압축 해제

```powershell
tar -xzf omo-plugin-airgap-YYYYMMDD.tar.gz
cd omo-plugin-airgap-YYYYMMDD
```

구조:

```
omo-plugin-airgap-YYYYMMDD/
├── README.md                          ← 이 문서
├── install.ps1                        ← 자동 설치 스크립트
├── MANIFEST.txt                       ← 버전/커밋/크기 정보
├── plugin/dist/                       ← 빌드된 플러그인 (index.js 등)
└── config-templates/
    ├── opencode.json.template         ← plugin 등록 예시(참고용 — install.ps1이 자동 처리)
    ├── oh-my-openagent.json           ← otel.enabled=true + 검증된 free 모델 매핑
    └── start-opencode.ps1             ← OTEL 환경변수 세팅 후 opencode 실행
```

---

## 4. 설치 (자동 스크립트 권장)

```powershell
# 관리자 권한 불필요 — 사용자 프로필 아래(%USERPROFILE%\.config\opencode)에 설정
.\install.ps1
# 설치 경로를 바꾸려면:
.\install.ps1 -InstallPath "D:\tools\oh-my-openagent-plugin"
```

**install.ps1이 하는 일** (전부 기존 설정을 백업한 뒤 병합 — 덮어쓰지 않음):
1. `plugin\dist\`를 설치 경로(기본 `C:\oh-my-openagent-plugin\dist`)로 복사
2. `%USERPROFILE%\.config\opencode\opencode.json`의 `plugin` 배열에 이 빌드의 `file:///.../dist/index.js`를 등록
   - 기존에 다른 `oh-my-openagent` 항목이 있으면(중복 등록은 OMO 자체 방어로 **자동 비활성화**되므로) 교체
   - 원본은 `opencode.json.bak-<timestamp>`로 백업
3. `%USERPROFILE%\.config\opencode\oh-my-openagent.json`
   - 없으면: 검증된 free 모델 매핑 + `otel.enabled: true` 템플릿을 새로 설치
   - 있으면: **모델 매핑 등 기존 설정은 그대로 두고** `otel.enabled: true`만 반영, 원본은 백업
4. `start-opencode.ps1`(OTEL 환경변수 3종 세팅 후 `opencode` 실행)을 설치 경로에 배치

---

## 5. 설치 (수동)

자동 스크립트를 쓰지 않을 경우:

```powershell
# 1) 플러그인 파일 배치
Copy-Item .\plugin\dist "C:\oh-my-openagent-plugin\dist" -Recurse -Force

# 2) opencode.json에 plugin 등록 (기존 파일이 있으면 직접 편집해서 plugin 배열에 추가)
notepad "$env:USERPROFILE\.config\opencode\opencode.json"
# "plugin": ["file:///C:/oh-my-openagent-plugin/dist/index.js"]

# 3) oh-my-openagent.json 배치 (없으면)
Copy-Item .\config-templates\oh-my-openagent.json "$env:USERPROFILE\.config\opencode\oh-my-openagent.json"

# 4) 실행 스크립트 배치
Copy-Item .\config-templates\start-opencode.ps1 "C:\oh-my-openagent-plugin\start-opencode.ps1"
```

> **주의**: `opencode.json`에 `oh-my-openagent` 플러그인이 **두 개 이상** 등록되면(예: `@latest`와 로컬 빌드가 동시에)
> OMO 자체 중복 방지 로직이 **자동으로 비활성화**시킵니다. 반드시 하나만 남기세요.

---

## 6. 사용 방법

### 6-1. 매번 이 스크립트로 실행

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\oh-my-openagent-plugin\start-opencode.ps1"
```

바로 `opencode`를 실행하면 OTEL 환경변수가 없어서 계측이 켜지지 않습니다(단, `oh-my-openagent.json`의
`otel.enabled: true`가 있으므로 `OTEL_EXPORTER_OTLP_ENDPOINT`만 기본값 `http://localhost:14318/v1/traces`로
해석되어 사실상 관측 스택이 로컬에 떠 있으면 이 스크립트 없이 맨 `opencode`만 실행해도 계측 자체는 동작합니다 —
스크립트는 어디로 보내는지 눈에 보이게 안내 메시지를 띄워주는 용도입니다).

여러 대의 개발자 PC에서 한 대의 공용 관측 서버로 보내려면, 실행 전에:

```powershell
$env:OTEL_EXPORTER_OTLP_ENDPOINT = "http://<관측서버IP>:14318/v1/traces"
$env:OMO_OTEL_ENABLED = "true"
opencode
```

### 6-2. 리빌드 후에는 반드시 opencode 재시작

플러그인은 opencode 프로세스 **시작 시점에 딱 1회** 메모리에 로드됩니다. `dist/`를 새로 교체했다면
기존에 열려 있던 opencode 창을 전부 닫고 새로 실행해야 반영됩니다. (`Get-Process opencode`로
여러 개 떠 있지 않은지 확인 — 옛 프로세스가 남아있으면 옛 코드로 계속 동작해서 혼란을 야기합니다.)

### 6-3. 정상 동작 확인 (End-to-End 체크리스트)

1. 관측 스택 확인: `docker compose ps` (전부 `Up`, `openlit-seed`만 `Exited (0)`)
2. `start-opencode.ps1`로 opencode 실행 → 아무 프롬프트나 입력
3. Jaeger UI(`http://localhost:26686`) → Service = `oh-my-openagent` → 최근 트레이스 확인
   - 루트 스팬 이름이 `user.prompt`이고 내가 입력한 문장이 `gen_ai.prompt` 속성에 그대로 보이면 정상
4. OpenLIT(`http://localhost:13000`) → Requests/Tokens 패널에 값이 채워지는지 확인
5. Grafana(`http://localhost:13001`) → `omo-overview`/`omo-traces` 대시보드에 그래프가 그려지는지 확인
6. (선택) ClickHouse 직접 조회로 원문 확인:
   ```powershell
   docker exec clickhouse-by-claude clickhouse-client --user default --password openlit123 --query "SELECT Timestamp, SpanName, SpanAttributes['gen_ai.prompt'] FROM openlit_db.otel_traces ORDER BY Timestamp DESC LIMIT 5"
   ```

데이터가 안 보이면 `AIRGAP-MONITORING-GUIDE.md` 11절(문제 해결) 및 아래 8절을 참고하세요.

---

## 7. 계측 켜기/끄기

| 상황 | 방법 |
|---|---|
| 완전히 끄기(성능/문제 발생 시) | `oh-my-openagent.json`에서 `"otel": {"enabled": false}` 또는 `$env:OMO_OTEL_ENABLED = "false"` |
| 다른 서버로 보내기 | `$env:OTEL_EXPORTER_OTLP_ENDPOINT = "http://<다른서버>:14318/v1/traces"` |
| 파일로만 저장(완전 폐쇄망, 스택 없이) | `$env:OMO_OTEL_EXPORTER = "file"` (`~/.cache/oh-my-openagent/traces.jsonl`에 JSONL로 저장) |

계측은 **opt-in**이며 (`OMO_OTEL_ENABLED` 기본값 `false`), Collector 연결이 안 되는 등 텔레메트리 실패는
전부 무시(silent catch)되므로 켜져 있어도 에이전트 동작 자체에는 영향을 주지 않습니다.

---

## 8. 문제 해결

| 증상 | 원인 / 해결 |
|---|---|
| opencode에 OMO 자체가 안 뜸(에이전트 명령어가 안 보임) | `opencode.json`의 `plugin` 배열에 oh-my-openagent 항목이 **2개 이상** 있는지 확인 — 있으면 하나만 남기고 재시작 |
| Jaeger에 트레이스가 안 보임 | ① `otel.enabled` 확인 ② `docker compose ps`로 스택이 떠 있는지 ③ opencode를 **완전히 재시작**했는지 |
| 트레이스는 있는데 `user.prompt`가 안 보이고 `session.turn`만 있음 | 이 버전(커밋 `c2387756c` 이상)에서 수정됨 — 이전 빌드라면 재패키징 필요 |
| 트레이스가 여러 개로 쪼개짐 | 10분 이상 대화가 비면 정상적으로 새 트레이스가 시작됩니다(설계된 동작) |
| 리빌드했는데 반영이 안 됨 | opencode 프로세스가 여전히 떠 있음 — `Get-Process opencode`로 확인 후 전부 종료하고 재실행 |

---

## 9. 이 패키지의 소스/버전 확인

`MANIFEST.txt`에 패키징 시점의 `package.json` 버전과 git 커밋 해시가 기록되어 있습니다.
소스는 `https://github.com/ultrapjg/ohmyopenagent` (fork), 브랜치 `oh-my-openagent-otel`.
