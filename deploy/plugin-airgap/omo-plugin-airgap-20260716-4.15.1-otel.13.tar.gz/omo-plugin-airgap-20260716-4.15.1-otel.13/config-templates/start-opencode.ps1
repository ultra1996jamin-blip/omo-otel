# Launch OpenCode with OTEL telemetry enabled.
# Run this instead of bare "opencode" to get traces in Jaeger/OpenLIT.
# Requires the observability stack (docker compose up -d) to be running first.

$env:OTEL_EXPORTER_OTLP_ENDPOINT = "http://localhost:14318/v1/traces"
$env:OTEL_SERVICE_NAME            = "oh-my-openagent"
$env:OMO_OTEL_ENABLED             = "true"

Write-Host "[OTEL] Sending traces to $env:OTEL_EXPORTER_OTLP_ENDPOINT" -ForegroundColor Cyan
Write-Host "[OTEL] Jaeger UI  : http://localhost:26686" -ForegroundColor Cyan
Write-Host "[OTEL] OpenLIT UI : http://localhost:13000" -ForegroundColor Cyan
Write-Host ""

opencode @args
