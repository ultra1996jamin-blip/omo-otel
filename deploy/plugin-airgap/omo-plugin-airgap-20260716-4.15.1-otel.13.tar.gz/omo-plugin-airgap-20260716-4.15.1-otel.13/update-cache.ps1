# ─────────────────────────────────────────────────────────────────────────────
# omo-plugin-cache-update.ps1  (패키지에 update-cache.ps1 로 포함됨)
#
# opencode는 "oh-my-opencode"/"oh-my-openagent"를 postinstall.mjs에 하드코딩된
# OPENCODE_PLUGIN_PACKAGES 목록으로 인식해서 npm으로 자동 설치해 로드합니다.
# 폐쇄망이라 이 npm install이 실패해서 "플러그인 인식 안 됨"이 발생하는 경우,
# opencode.json을 건드리는 대신 이미 존재하는 설치 폴더 안의 dist/packages만
# 우리가 빌드한 걸로 직접 교체하면 됩니다 — 네트워크/npm 불필요.
#
# 정확히 "어느 폴더"를 opencode가 실제로 로드하는지는 환경마다 다를 수 있어서
# (opencode 자체 plugin 캐시 vs npm 전역 설치), 알려진 후보를 전부 찾아서
# 존재하는 것마다 갱신합니다 — 두 이름(oh-my-opencode / oh-my-openagent) x
# 두 위치(opencode 자체 캐시 / npm 전역 설치) 조합.
#
# 사용법:
#   pwsh .\update-cache.ps1
#   (선택) -UserProfile 로 다른 사용자 계정 경로 지정 가능
# ─────────────────────────────────────────────────────────────────────────────
param(
  [string]$UserProfile = $env:USERPROFILE
)
$ErrorActionPreference = "Stop"
function info { param($m) Write-Host "[INFO]  $m" -ForegroundColor Green }
function step { param($m) Write-Host "[STEP]  $m" -ForegroundColor Cyan }
function warn { param($m) Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function err  { param($m) Write-Host "[ERROR] $m" -ForegroundColor Red; exit 1 }

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
$pluginDistSrc = Join-Path $ROOT "plugin\dist"
$pluginPackagesSrc = Join-Path $ROOT "plugin\packages"

if (-not (Test-Path $pluginDistSrc)) { err "$pluginDistSrc 없음 — 패키지가 손상된 것 같습니다" }

$PACKAGE_NAMES = @("oh-my-openagent", "oh-my-opencode")
$appData = Join-Path $UserProfile "AppData\Roaming"
$xdgCache = if ($env:XDG_CACHE_HOME) { $env:XDG_CACHE_HOME } else { Join-Path $UserProfile ".cache" }

# 후보 1: opencode 자체의 plugin 자동설치 캐시 — 이름@태그 폴더 아래 node_modules\이름
#         (예: .cache\opencode\packages\oh-my-openagent@latest\node_modules\oh-my-openagent)
function Get-OpencodeCacheTargets {
  $cachePackagesDir = Join-Path $xdgCache "opencode\packages"
  if (-not (Test-Path $cachePackagesDir)) { return @() }
  $targets = @()
  foreach ($name in $PACKAGE_NAMES) {
    $matches = Get-ChildItem $cachePackagesDir -Directory -Filter "$name@*" -ErrorAction SilentlyContinue
    foreach ($m in $matches) {
      $t = Join-Path $m.FullName "node_modules\$name"
      if (Test-Path $t) { $targets += $t }
    }
  }
  return $targets
}

# 후보 2: npm 전역 설치 (npm install -g oh-my-opencode 등) — AppData\Roaming\npm\node_modules\이름
function Get-GlobalNpmTargets {
  $npmNodeModules = Join-Path $appData "npm\node_modules"
  if (-not (Test-Path $npmNodeModules)) { return @() }
  $targets = @()
  foreach ($name in $PACKAGE_NAMES) {
    $t = Join-Path $npmNodeModules $name
    if (Test-Path $t) { $targets += $t }
  }
  return $targets
}

step "STEP 1: 설치 폴더 후보 탐색"
$allTargets = @(Get-OpencodeCacheTargets) + @(Get-GlobalNpmTargets) | Select-Object -Unique
if (-not $allTargets -or $allTargets.Count -eq 0) {
  err "oh-my-opencode/oh-my-openagent 설치 폴더를 어디서도 찾지 못했습니다 (opencode 캐시, npm 전역 설치 둘 다 없음). omo-plugin-install.ps1(file:// 방식)을 대신 사용하세요."
}
foreach ($t in $allTargets) { info "  발견: $t" }

$timestamp = Get-Date -Format "yyyyMMddHHmmss"

foreach ($targetRoot in $allTargets) {
  Write-Host ""
  step "갱신: $targetRoot"

  $distTarget = Join-Path $targetRoot "dist"
  if (Test-Path $distTarget) {
    Rename-Item $distTarget "dist.bak-$timestamp" -Force
    info "  백업: dist -> dist.bak-$timestamp"
  }
  Copy-Item $pluginDistSrc $distTarget -Recurse -Force
  info "  교체 완료: dist"

  foreach ($sub in @("lsp-tools-mcp", "lsp-daemon")) {
    $subDistTarget = Join-Path $targetRoot "packages\$sub\dist"
    if (Test-Path $subDistTarget) {
      Rename-Item $subDistTarget "dist.bak-$timestamp" -Force
      info "  백업: packages\$sub\dist -> packages\$sub\dist.bak-$timestamp"
    }
    $subSrc = Join-Path $pluginPackagesSrc "$sub\dist"
    if (Test-Path $subSrc) {
      $subDstDir = Join-Path $targetRoot "packages\$sub"
      New-Item -ItemType Directory -Force -Path $subDstDir | Out-Null
      Copy-Item $subSrc (Join-Path $subDstDir "dist") -Recurse -Force
      info "  교체 완료: packages\$sub\dist"
    }
  }
}

Write-Host ""
step "완료"
warn "opencode를 이미 띄워 놓은 상태였다면 반드시 완전히 재시작하세요 — 플러그인은 시작 시 1회만 로드됩니다."
info "opencode.json은 건드리지 않았습니다 — 위에서 발견된 설치 폴더들만 교체했습니다."
